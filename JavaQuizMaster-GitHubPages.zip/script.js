// Java Quiz Master — frontend-only edition for GitHub Pages.
// Questions and answer keys live in this file; no Java server or API is required.

const questions = [
  {
    id: 1,
    question: "Which concept allows a Java class to acquire properties of another class?",
    options: ["Encapsulation", "Inheritance", "Polymorphism", "Abstraction"],
    answer: "B"
  },
  {
    id: 2,
    question: "Which keyword prevents a method from being overridden?",
    options: ["static", "private", "final", "abstract"],
    answer: "C"
  },
  {
    id: 3,
    question: "Which collection does not allow duplicate elements?",
    options: ["ArrayList", "LinkedList", "HashSet", "Vector"],
    answer: "C"
  },
  {
    id: 4,
    question: "What is the default value of an instance int variable in Java?",
    options: ["null", "0", "1", "Undefined"],
    answer: "B"
  },
  {
    id: 5,
    question: "Which exception occurs when dividing an integer by zero?",
    options: ["IOException", "NullPointerException", "ArithmeticException", "ClassNotFoundException"],
    answer: "C"
  },
  {
    id: 6,
    question: "Which Java feature allows the same method name with different parameters?",
    options: ["Method Overriding", "Method Overloading", "Inheritance", "Encapsulation"],
    answer: "B"
  },
  {
    id: 7,
    question: "Which interface is the parent of all collection types in Java?",
    options: ["List", "Set", "Collection", "Map"],
    answer: "C"
  },
  {
    id: 8,
    question: "Which keyword is used to implement an interface in Java?",
    options: ["extends", "implements", "interface", "import"],
    answer: "B"
  },
  {
    id: 9,
    question: "Which of these is used to create a new thread in Java?",
    options: ["Thread class", "Scanner class", "String class", "System class"],
    answer: "A"
  },
  {
    id: 10,
    question: "Which SQL command is used to retrieve data from a table?",
    options: ["INSERT", "UPDATE", "DELETE", "SELECT"],
    answer: "D"
  }
];

const LETTERS = ["A", "B", "C", "D"];
const QUESTION_SECONDS = 20;
const HISTORY_KEY = "javaQuizMasterHistory";

let currentIndex = 0;
let answers = {};
let selectedOption = null;
let timerInterval = null;
let timeLeft = QUESTION_SECONDS;
let hasSubmitted = false;

const startScreen = document.getElementById("start-screen");
const quizScreen = document.getElementById("quiz-screen");
const resultScreen = document.getElementById("result-screen");
const startBtn = document.getElementById("start-btn");
const nextBtn = document.getElementById("next-btn");
const restartBtn = document.getElementById("restart-btn");
const historyBtn = document.getElementById("history-btn");
const errorMessage = document.getElementById("error-message");

startBtn.addEventListener("click", startQuiz);
nextBtn.addEventListener("click", () => {
  if (selectedOption === null) return;
  answers[questions[currentIndex].id] = selectedOption;
  moveNext();
});
restartBtn.addEventListener("click", () => {
  stopTimer();
  resultScreen.classList.add("hidden");
  document.getElementById("history").replaceChildren();
  errorMessage.textContent = "";
  startScreen.classList.remove("hidden");
});
historyBtn.addEventListener("click", showHistory);

function startQuiz() {
  stopTimer();
  currentIndex = 0;
  answers = {};
  hasSubmitted = false;
  errorMessage.textContent = "";
  startScreen.classList.add("hidden");
  resultScreen.classList.add("hidden");
  quizScreen.classList.remove("hidden");
  showQuestion();
}

function showQuestion() {
  stopTimer();
  selectedOption = null;
  timeLeft = QUESTION_SECONDS;

  const question = questions[currentIndex];
  document.getElementById("question-number").textContent =
    `Question ${currentIndex + 1} of ${questions.length}`;
  document.getElementById("question-text").textContent = question.question;
  document.getElementById("timer").textContent = `${timeLeft} seconds`;
  document.getElementById("progress-bar").style.width =
    `${(currentIndex / questions.length) * 100}%`;

  const optionsContainer = document.getElementById("options-container");
  optionsContainer.replaceChildren();

  question.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "option";
    button.textContent = `${LETTERS[index]}. ${option}`;
    button.addEventListener("click", () => {
      selectedOption = LETTERS[index];
      optionsContainer.querySelectorAll(".option").forEach(item => {
        item.classList.remove("selected");
        item.setAttribute("aria-pressed", "false");
      });
      button.classList.add("selected");
      button.setAttribute("aria-pressed", "true");
      nextBtn.disabled = false;
    });
    button.setAttribute("aria-pressed", "false");
    optionsContainer.appendChild(button);
  });

  nextBtn.disabled = true;
  nextBtn.textContent = currentIndex === questions.length - 1
    ? "Submit Quiz"
    : "Next Question";

  startTimer();
}

function startTimer() {
  timerInterval = setInterval(() => {
    timeLeft -= 1;
    document.getElementById("timer").textContent = `${timeLeft} seconds`;

    if (timeLeft <= 0) {
      stopTimer();
      // A blank answer is deliberately recorded as unanswered/incorrect.
      answers[questions[currentIndex].id] = selectedOption || "";
      moveNext();
    }
  }, 1000);
}

function stopTimer() {
  if (timerInterval !== null) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

function moveNext() {
  stopTimer();
  currentIndex += 1;
  if (currentIndex < questions.length) {
    showQuestion();
  } else {
    submitQuiz();
  }
}

function submitQuiz() {
  if (hasSubmitted) return;
  hasSubmitted = true;
  stopTimer();
  quizScreen.classList.add("hidden");

  let score = 0;
  questions.forEach(question => {
    if (answers[question.id] === question.answer) score += 1;
  });

  const total = questions.length;
  const percentage = Math.round((score / total) * 100);
  let feedback;

  if (percentage >= 80) {
    feedback = "Excellent work! You have a strong understanding of these topics.";
  } else if (percentage >= 50) {
    feedback = "Good effort! Review a few topics and try again to improve your score.";
  } else {
    feedback = "Keep practising! Review the Java fundamentals and take the quiz again.";
  }

  document.getElementById("final-score").textContent = `${score}/${total}`;
  document.getElementById("percentage").textContent = `${percentage}%`;
  document.getElementById("feedback").textContent = feedback;
  document.getElementById("progress-bar").style.width = "100%";
  resultScreen.classList.remove("hidden");

  saveResult({ score, total, percentage, date: new Date().toLocaleString() });
}

function readHistory() {
  try {
    const saved = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function saveResult(result) {
  try {
    const history = readHistory();
    history.unshift(result);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 10)));
  } catch {
    // Quiz scoring still works if browser storage is disabled or full.
  }
}

function showHistory() {
  const container = document.getElementById("history");
  container.replaceChildren();

  const heading = document.createElement("h3");
  heading.textContent = "Previous Quiz Results";
  container.appendChild(heading);

  const history = readHistory();
  if (history.length === 0) {
    const message = document.createElement("p");
    message.textContent = "No previous results on this browser yet.";
    container.appendChild(message);
    return;
  }

  history.forEach(item => {
    const entry = document.createElement("p");
    entry.textContent =
      `${item.date} — ${item.score}/${item.total} (${item.percentage}%)`;
    container.appendChild(entry);
  });

  const note = document.createElement("small");
  note.textContent = "History is saved only in this browser on this device.";
  container.appendChild(note);
}
