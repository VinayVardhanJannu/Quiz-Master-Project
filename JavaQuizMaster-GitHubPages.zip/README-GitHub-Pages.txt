# Java Quiz Master — GitHub Pages Edition

This is the frontend-only edition of the Java Quiz Master project. It runs entirely in the browser using HTML, CSS and JavaScript. It does not require Java, a server, a database, or API endpoints.

## Features
- 10 Java and programming questions
- 20-second timer per question
- Multiple-choice answers
- Automatic scoring and percentage
- Result feedback
- Result history saved in the current browser using localStorage

## Run locally
Open `index.html` in a modern web browser.

## Publish on GitHub Pages
1. Extract this ZIP.
2. Open your existing repository: https://github.com/VinayVardhanJannu/Quiz-Master-Project
3. Upload `index.html`, `style.css`, and `script.js` to the repository root (same level as README.md).
4. Commit the changes to the `main` branch.
5. Open repository **Settings → Pages**.
6. Under **Build and deployment**, select **Deploy from a branch**.
7. Select branch **main** and folder **/(root)**, then click **Save**.
8. Wait for deployment and open: https://vinayvardhanjannu.github.io/Quiz-Master-Project/

## Important
GitHub Pages hosts static files only. This edition intentionally replaces backend API calls with browser-side JavaScript. Scores are calculated in the browser and history is stored locally in each visitor's browser. It is not a shared leaderboard and users can inspect the answer key in the public JavaScript source.
