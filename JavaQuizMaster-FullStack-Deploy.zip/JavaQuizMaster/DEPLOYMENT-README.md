# Java Quiz Master — Full-stack deployment edition

This version keeps your original HTML/CSS/JavaScript frontend and Java HTTP backend.

## Project structure
- `src/Question.java` — question model
- `src/QuestionService.java` — quiz question data
- `src/QuizService.java` — scoring and in-memory result history
- `src/QuizServer.java` — Java HTTP server and API routes
- `web/` — frontend files
- `Dockerfile` — builds and runs the app on a Docker-capable host

## Run locally (Java 17+)
From this `JavaQuizMaster` directory:

```bash
javac -d out src/*.java
java -cp out QuizServer
```

Then open `http://localhost:8080`.

## Deploy online
Push the contents of this `JavaQuizMaster` folder to your GitHub repository. On a Docker-capable hosting service such as Railway:
1. Create a new project/service from your GitHub repository.
2. Select the repository and branch.
3. Set the service's Root Directory to `JavaQuizMaster` if the folder is nested in the repository. If you put these files at repository root, leave Root Directory blank.
4. Choose Dockerfile deployment (the Dockerfile is included).
5. Deploy and open the generated public domain.

The server reads the hosting platform's `PORT` environment variable and binds to `0.0.0.0`.

## Notes
- Frontend and backend are served from the same application/domain, so the existing `/api/questions`, `/api/submit`, and `/api/history` calls remain same-origin.
- Result history is currently held in memory and will reset when the service restarts or redeploys. A database is needed for permanent shared history.
- GitHub Pages cannot run this Java backend. Use GitHub for source control and the Java-capable host for the live application.
